from flask import Flask, render_template, request, redirect, jsonify
import sqlite3
import nmap

app = Flask(__name__)

# ---------------- DATABASE ----------------
def init_db():
    conn = sqlite3.connect("devices.db")
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS devices(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        ip TEXT,
        type TEXT
    )
    """)

    conn.commit()
    conn.close()

init_db()

# ---------------- HOME ----------------
@app.route("/")
def home():
    return render_template("login.html")

# ---------------- DASHBOARD ----------------
@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

# ---------------- ADD DEVICE ----------------
@app.route("/add_device", methods=["GET","POST"])
def add_device():
    if request.method == "POST":
        name = request.form["name"]
        ip = request.form["ip"]
        dtype = request.form["type"]

        conn = sqlite3.connect("devices.db")
        c = conn.cursor()

        c.execute("INSERT INTO devices(name,ip,type) VALUES(?,?,?)",(name,ip,dtype))

        conn.commit()
        conn.close()

        return redirect("/dashboard")

    return render_template("add_device.html")

# ---------------- GET DEVICES API ----------------
@app.route("/api/devices")
def get_devices():
    conn = sqlite3.connect("devices.db")
    c = conn.cursor()

    c.execute("SELECT * FROM devices")
    data = c.fetchall()

    conn.close()

    return jsonify({"devices": data})

# ---------------- DISCOVER DEVICES ----------------
@app.route("/discover")
def discover():
    return render_template("discover.html")

# ---------------- SCAN FUNCTION ----------------
def analyze_port(port):
    high = [21,23,445,139]
    medium = [22,25,80,111]

    if port in high:
        return "HIGH"
    elif port in medium:
        return "MEDIUM"
    else:
        return "LOW"

def calculate_score(results):
    score = 0

    for r in results:
        if r[2] == "HIGH":
            score += 20
        elif r[2] == "MEDIUM":
            score += 10
        else:
            score += 2

    return min(score,100)

# ---------------- SCAN ROUTE ----------------
@app.route("/scan/<target>")
def scan(target):

    nm = nmap.PortScanner()
    nm.scan(hosts=target, arguments="-F")

    results = []

    for host in nm.all_hosts():
        if 'tcp' in nm[host]:
            for port in nm[host]['tcp']:
                state = nm[host]['tcp'][port]['state']
                risk = analyze_port(port)

                results.append((port, state, risk))

    score = calculate_score(results)

    return render_template("result.html", results=results, target=target, score=score)

# ---------------- RUN ----------------
if __name__ == "__main__":
    app.run(debug=True)
import sqlite3

conn = sqlite3.connect("devices.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS devices (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
ip TEXT,
type TEXT
)
""")

conn.commit()
conn.close()

print("Database created successfully")